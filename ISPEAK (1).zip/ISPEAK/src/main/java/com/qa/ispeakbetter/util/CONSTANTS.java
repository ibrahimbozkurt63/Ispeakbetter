package com.qa.ispeakbetter.util;



public class CONSTANTS {
	public static final String GREETINGNAME="Adem";
	public static final String HEADERLIST="[Dictionary, Library, Messages,  Sign Out]";
	public static final String CHATWAITINGAREA="Please wait while";
	public static final String LOGINPAGETITLE="Learn English with Online Teachers - Get your Free Live English Class Now.";
	public static final String HOMEPAGETITLE="Learn English with Online Teachers - Get your Free Live English Class Now.";
	public static final String ISEPAKURL="https://ispeakbetter.com/";
	
	
}
